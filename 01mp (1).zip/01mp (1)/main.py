from CreditPaymentsModule import CreditPayments

print("Enter deal ID:")
inputID = 2

print("Enter date:")
inputDate = '08.2018'

print("---------")

pObject = CreditPayments()
print("Summ of credit = {}".format(pObject.getSummOfCredit(id=inputID)))
print("Rest summ of credit after {} = {}".format(inputDate,pObject.getRestOfCredit(id=inputID, date=inputDate)))