import pandas as pd

class CreditPayments:

    def __init__(self):
        # Считываем данные из файла CSV в DataFrame
        self.data = pd.read_csv('data.csv', delimiter=';')

    # Метод для поиска индекса даты в строке
    def find_date_index(self, x):
        k = x.keys()
        i = 0
        while i < len(k):
            if k[i] == self.date:
                return i
            i = i + 1
        return -1

    # Метод для вычисления остатка кредита
    def calc_rest(self, x):
        if int(x['Deal ID']) == self.id:
            summ = x['Summ of credit']
            payed = 0.0
            max = self.find_date_index(x)

            if max < 0:
                self.res = 'Wrong date'
                return

            i = 2
            while i <= max:
                payed = payed + x[i]
                i = i + 1

            self.res = summ - payed

        return

    # Метод для получения остатка кредита по номеру договора и дате
    def getRestOfCredit(self, id, date):
        # Записываем переданные аргументы в свойства объекта
        self.id = int(id)
        self.date = date

        # Применяем метод calc_rest к каждой строке DataFrame
        self.data.apply(self.calc_rest, axis=1)

        # Возвращаем результат
        return self.res

    # Метод для получения суммы кредита по номеру договора
    def get_summ(self, x):
        # Когда 'Deal ID' совпадает с self.id, записываем 'Summ of credit' в self.res
        if int(x['Deal ID']) == self.id:
            self.res = x['Summ of credit']

    # Метод для получения суммы кредита по номеру договора
    def getSummOfCredit(self, id):
        # Записываем переданный номер договора в свойство объекта
        self.id = int(id)

        # Применяем метод get_summ к каждой строке DataFrame
        self.data.apply(self.get_summ, axis=1)

        # Возвращаем результат
        return self.res
